/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.5.39 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580316_shopcar` (
	`name` varchar (765),
	`price` int (11)
); 
