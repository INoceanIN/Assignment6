/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.5.39 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580316_pet` (
	`id` int (11),
	`name` varchar (765),
	`eat` varchar (765),
	`drink` varchar (765),
	`live` varchar (765),
	`hobby` varchar (765),
	`price` int (11)
); 
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('1','dog','bone','water','ground','play','100');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('2','cat','fish','milk','roof','hug','200');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('3','turtle','fish,shrimp','sea water','sea water','bask','300');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('4','parrot','nuts,seeds','water','tree','fly','400');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('5','hamster','Sunflower seed','water','corner','eat','500');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('6','squirrel','pine cone','water','tree hole,underground','play','600');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('7','rabbit','carrot','water','grassland,underground','eat','700');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('8','snake','mouse','water','hole','bask','800');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('9','lizard','bug','water','tree','bask','900');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('10','fish','aquatic plant','water','water','swim','1000');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('11','myna','earthworm','water','tree','fly','1100');
insert into `2014302580316_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`) values('12','canary','millet','water','tree','sing','1200');
